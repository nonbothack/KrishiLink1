# OpenUser runs

## Tool and daemon

- Repository: https://github.com/manalkaff/openuser
- Package: `openuser-cli` 0.1.1
- Daemon: `http://127.0.0.1:8737` (localhost only)
- Configuration: project base URL first `http://localhost:5173`, then patched for test execution to `http://localhost:5174`; no production configuration was changed.
- Browser: Playwright Chromium installed locally by `npx playwright install chromium`.
- Credentials were used only in the local demo/test database; they are not recorded here.

## Runs

| Run | Base URL | Scenario | Result | Evidence |
|---|---|---|---|---|
| `run_KNWrj60n_VaW` | 5173 | first-time farmer checks price and Sell | failed; price API was same-origin SPA because the static preview had no API proxy; CSP inline-script errors were also reported | OpenUser artifact under `C:\Users\a\.openuser\artifacts\run_KNWrj60n_VaW` |
| `run_SdrbfNqzHXmX` | 5174 | farmer checks price and Sell through Vite proxy | `goal_achieved`; truthful empty state was observed, login fixture was rejected with HTTP 401 | OpenUser artifact under `C:\Users\a\.openuser\artifacts\run_SdrbfNqzHXmX` |
| `run_GJQ_ufntLyry` | 5174 | farmer checks price, uses synthetic account, reaches Sell | blocked; backend rejected temporary 5174 browser origin with HTTP 403 | OpenUser artifact under `C:\Users\a\.openuser\artifacts\run_GJQ_ufntLyry` |

The first run's `critical` OpenUser label is retained as tool evidence. After inspection, its price failure is triaged to the incorrectly configured static preview and empty official dataset, not to permission to fabricate a price. The 5174 runs show the app's honest `No prices reported for these filters` state. Login could not be completed in this harness because the active backend origin allow-list did not accept the temporary 5174 origin; no security control was weakened to force the run through.
