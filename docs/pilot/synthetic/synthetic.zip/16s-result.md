# Packet 16S — Synthetic User Simulation & UX Stress Test

**Status: FAIL**

This status applies only to the synthetic rehearsal. Real Packet 16 remains **BLOCKED / INSUFFICIENT** because no paid, consented participants have completed sessions.

## 1. Executive summary

The synthetic infrastructure executed successfully enough to expose two environment-bound P1 blockers and one useful P2 semantic question. OpenUser confirmed that a correctly proxied frontend preserves a truthful no-price state when the official observation dataset is empty. It did not complete authenticated Sell because the temporary test origin was rejected by the backend origin guard. The initial static preview also lacked an API proxy. MiroFish completed one three-round synthetic multi-stakeholder simulation and repeatedly highlighted source/date/unit, staged Sell, offline-state, and payment-evidence wording. No KrishiLink product code was changed in this packet.

## 2. Tool versions

- OpenUser CLI: 0.1.1
- OpenUser daemon: local `127.0.0.1:8737`
- Chromium: Playwright-managed Chrome for Testing 153.0.8010.12
- MiroFish: `uv` 0.12.17, isolated Python 3.12.14
- Codex CLI: 0.155.0-alpha.9.2
- Node: v24.13.0; npm: 11.6.2
- Python available in KrishiLink shell: 3.14.3; MiroFish used isolated 3.12.14
- Docker CLI was unavailable in the current shell; no Docker claim is made here.

## 3. Exact repository URLs

- KrishiLink: `C:\abdul`
- Frontend tested: `http://localhost:5173` static preview and `http://localhost:5174` Vite dev server
- Backend tested: `http://localhost:8001`
- Frontend health: `http://localhost:5173/health` returned 200
- Backend API health: `http://localhost:8001/api/v1/health` returned 200 in demo mode

## 4. Tool commit SHAs

- MiroFish: `d8dc889433b116247475db9830788dea224400e1`
- OpenUser was run from npm package 0.1.1; no repository SHA was available from the package invocation.

## 5. Installation method

OpenUser was installed with `npx --yes openuser-cli` using a clean local npm cache, then Chromium was installed with `npx playwright install chromium`. MiroFish was cloned to `C:\krishilink-sim-tools\mirofish`, synchronized with an isolated `uv` Python 3.12 environment, and kept outside KrishiLink. A rapidfuzz lock refresh was required for Windows compatibility in the external checkout only.

## 6. Security review

OpenUser ran against localhost and the daemon was bound to `127.0.0.1`. Synthetic credentials were used only in a local test database and are omitted from committed evidence. The MiroFish source pack was redacted and contained no secrets or private records. No origin guard, CSP, authentication, or production provider control was weakened. Full artifacts remain outside the repository.

## 7. KrishiLink build tested

The existing working tree build was tested; no Packet 16S product changes were made. The static 5173 preview and a temporary 5174 Vite server were both examined because their API behavior differed.

## 8. Environment

The backend and frontend health endpoints were reachable. The official price endpoint returned an empty observation list, so a no-price state was the expected truthful result. The 5173 static preview had no `/api` proxy and returned the SPA shell for same-origin API paths. The 5174 test server proxied API requests to port 8001, but the active backend origin allow-list rejected the temporary browser origin for login.

## 9. OpenUser configuration

One local project was registered, first at 5173 and then patched to 5174 through the local OpenUser API. Tester runs used the OpenUser tester MCP role and local browser artifacts. Generated OpenUser config/skill files were setup artifacts and are removed before completion.

## 10. OpenUser smoke

Three farmer personas/runs were created. The first run could not load prices because of the static preview configuration. The second reached the price page through the proxy and saw `No prices reported for these filters. Try another crop or market.` The third reached the same truthful state but was blocked by HTTP 403 when trying to log in through the temporary origin.

## 11. Farmer persona matrix

Target 15; executed three synthetic farmer personas: novice 360x640, novice 360x640, and novice 390x844. Coverage was English price-empty state, Sell entry, and login boundary. No result is real farmer evidence.

## 12. Buyer persona matrix

Target seven; no browser buyer personas executed. Buyer concerns were represented only as a role in the MiroFish source pack and simulation. Browser buyer validation remains open.

## 13. FPO persona matrix

Target five; no browser FPO personas executed. Traceability and offline-state concerns were represented only in MiroFish. Browser FPO validation remains open.

## 14. Operations personas

Target three; no browser operations personas executed. The platform/operations perspective appeared in the MiroFish simulation only.

## 15. OpenUser run count

Three OpenUser runs were created. One initial attempt before Chromium installation failed as setup/tooling. Two post-setup runs completed or reached a terminal blocked state. This is a smoke subset, not the requested approximately 30-persona matrix.

## 16. OpenUser goal-achieved/partial/blocked counts

Among post-setup runs: one `goal_achieved` (truthful unavailable price plus Sell entry, login fixture failed with 401) and one `blocked` (truthful unavailable price plus 403 origin rejection). The initial setup failure is excluded from product outcome counts.

## 17. OpenUser P0

No P0 finding was established. No cross-account, privacy, data-loss, or authorization exposure was observed.

## 18. OpenUser P1

Two P1 environmental blockers remain: the static preview's missing API proxy and the temporary 5174 origin rejection during login. OpenUser labeled the original price finding `critical`; root-cause inspection showed the backend had no price observations and the static preview was misconfigured for same-origin API access. These are not grounds to fabricate data or weaken origin security.

## 19. OpenUser P2/P3

The correctly proxied run produced a P2-style expected-unavailable observation: the empty official dataset is communicated clearly, but there is no price comparison until a genuine observation exists. This needs real-user comprehension validation and a seeded staging fixture for positive paths.

## 20. MiroFish configuration

MiroFish ran externally with an explicit UTF-8 environment because the first Windows Codex subprocess emitted invalid UTF-8 and timed out. The successful run used three rounds and a redacted KrishiLink source pack.

## 21. MiroFish source pack

The pack contained product context, farmer/buyer/FPO flows, truth and trust rules, and pilot questions under `C:\krishilink-sim-tools\mirofish-input\krishilink`. It contained no real participants, secrets, market records, or production exports.

## 22. MiroFish farmer simulation

Synthetic farmer agents repeatedly asked whether reported prices were official, current, local, comparable, and the amount they would receive. This is a simulated question pattern only.

## 23. MiroFish buyer simulation

Synthetic buyer agents questioned whether a displayed value was an official reference or a confirmed offer and whether Sell created a binding commitment. No buyer behavior claim is made.

## 24. MiroFish FPO simulation

Synthetic FPO agents focused on separating local member records from published lots and on synchronization/audit state. No FPO throughput or traceability claim is made.

## 25. Cross-stakeholder simulation

The platform agent attempted to clarify price metadata, staged Sell, offline status, and payment evidence. The report itself warns that compressed wording can create new ambiguity.

## 26. Cross-tool convergence

Only weak thematic convergence exists: OpenUser observed a no-price state with no fabricated metadata, while MiroFish raised questions about source/date/unit and transaction meaning. This is not statistically valid convergence and does not replace real sessions.

## 27. Baseline findings

Findings are recorded in `synthetic-findings.md` as `S16-001` through `S16-004`. The baseline exposed an unsupported browser deployment path and an unexecuted authenticated Sell journey. No product fix was made before evidence capture.

## 28. Fixes implemented

No KrishiLink product fixes were implemented. Only external test setup was performed: OpenUser/Chromium installation, an isolated Vite proxy on 5174, and a local synthetic fixture account. The temporary account and harness artifacts are not production fixtures.

## 29. Tests added

No application tests were added. Existing Packet 16 research infrastructure and the existing repository test suite were reused. Synthetic evidence is deliberately excluded from the real pilot analyzer.

## 30. Re-run results

The 5174 rerun removed the first run's API-proxy failure and demonstrated the honest no-price message. The authenticated rerun still stopped at the backend origin guard. A supported staging origin is required before declaring the Farmer → Sell path synthetically clear.

## 31. Remaining synthetic P0/P1

No P0 remains. Two P1 environment/test-path blockers remain unresolved: supported API deployment for browser testing and supported origin configuration for authenticated testing. Because an essential journey was not completed, Packet 16S is `FAIL` rather than `PASS_WITH_FINDINGS`.

## 32. Language issues requiring native review

MiroFish raised English semantic distinctions around “reported,” “official,” “queued,” “published,” “payment initiated,” and “settled.” Hindi and Marathi wording was not independently reviewed by native speakers in this packet. No claim of translation comprehension is made.

## 33. Accessibility issues requiring human review

No dedicated OpenUser accessibility audit or assistive-technology session was completed. Keyboard, screen-reader, focus, touch-target, and 200% text behavior remain real-user/manual review priorities.

## 34. Real-user validation priorities

First validate source/date/unit and non-guarantee language with farmers and buyers. Then validate the Sell commitment boundary, offline status vocabulary, payment evidence labels, and FPO traceability language with the named participant panel. Use paid, consented sessions and the existing anonymized schema.

## 35. Regression results

`python -m pytest -q` was rerun from `backend/` and exited 0 with no failed or skipped tests; the run completed with one existing pytest-asyncio deprecation warning. Packet 16’s recorded baseline remains 225 backend tests, 40 frontend unit tests, and 30 browser tests passing. No Packet 16S code change was made to regress those results. Frontend lint/build/E2E results are inherited from Packet 16 and were not rerun because this packet made no frontend changes.

## 36. Files changed

Only `docs/pilot/synthetic/` evidence files were added. Temporary OpenUser/Vite wrapper files and generated OpenUser project files are removed before completion. No application source, migration, or real Packet 16 result file is changed.

## 37. Git status

The working tree already contains extensive uncommitted Packet 00–16 work. Packet 16S adds only the synthetic evidence directory; no commit, push, tag, merge, or deployment was performed.

## 38. Final recommendation

**Synthetic usability rehearsal: FAIL**

**Real Packet 16 evidence: BLOCKED / INSUFFICIENT**

**Engineering RC: READY unless a supported synthetic staging rerun exposes an engineering P0/P1 that remains unresolved**

**Recommended next action: FIX AND RE-RUN SYNTHETIC TESTS**, then proceed to the real paid/consented pilot. Do not create Packet 17 and do not treat this synthetic result as real user validation.
